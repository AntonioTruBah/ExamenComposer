<?php

namespace AntonioTB\modelo;
require "../../../vendor/autoload.php";
use PHPUnit\Framework\TestCase;

class ConversorTemperaturasTest extends TestCase
{

    public function testCelsiusToFarenheit()
    {
        $conversor = new ConversorTemperaturas();

        $grado_0_32F = $conversor->CelsiusToFarenheit(0);
        $this->assertEquals(32,$grado_0_32F);
        $grado_50_122F = $conversor->CelsiusToFarenheit(50);
        $this->assertEquals(122,$grado_50_122F);

        $grado_500_932F = $conversor->CelsiusToFarenheit(500);
        $this->assertEquals(932,$grado_500_932F);

        $grado_501_ERROR = $conversor->CelsiusToFarenheit(501);
        $this->assertEquals(PHP_FLOAT_MAX,$grado_501_ERROR);

    }

    public function testFarenheitToCelsius()

    {
        $conversor = new ConversorTemperaturas();

        $farenheit_0_1777C = $conversor->FarenheitToCelsius(0);
        $this->assertEquals(-17.78,floor($farenheit_0_1777C*100) / 100);

        $farenheit_200_9333C = $conversor->FarenheitToCelsius(200);
        $this->assertEquals(93.33,floor($farenheit_200_9333C*100)/100);

        $farenheit_600_315C = $conversor->FarenheitToCelsius(600);
        $this->assertEquals(315.55,floor($farenheit_600_315C*100)/100);

        $farenheit_932_500C = $conversor->FarenheitToCelsius(932);
        $this->assertEquals(500,$farenheit_932_500C);
    }
}