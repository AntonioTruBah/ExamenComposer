<?php


namespace AntonioTB\modelo;


class ConversorTemperaturas
{
    public function CelsiusToFarenheit($grados){
        if ($grados > 500)
            return PHP_FLOAT_MAX;
        else
        return ($grados * 9/5) + 32;
    }

    public function FarenheitToCelsius($farenheit){
        if ($farenheit > 932)
            return PHP_FLOAT_MAX;
        else
            return ($farenheit - 32) * 5/9;
    }
}